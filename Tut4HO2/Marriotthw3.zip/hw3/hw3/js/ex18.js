
const x = "abc";
switch (x) {
  case "abc":
    console.log("Answer: ","x = abc");
    break;
  case "def":
    console.log("x = def");
    break;
}

//const x = "abc";
switch (x) {
case "abc":
console.log("Answer: ","x = abc");
//no break
case "def":
console.log("Answer: ","x = def");
break;
}