let i = 1;
if ((1 > 2) && i++) {
   //Nothing.  Want to test condition
}
console.log("Answer: ",`The value of i is: ${i}`);


if ((1 < 2) && i++) {
   //Nothing.  Want to test condition
}
console.log("Answer: ",`The value of i is: ${i}`);
