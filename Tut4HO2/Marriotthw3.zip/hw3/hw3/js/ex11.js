console.log("Answer: ",4 + 5);


console.log("Answer: ","4 + 5");


console.log("Answer: ","4" + "5");


console.log("Answer: ",2 + 3 * 5);


console.log("Answer: ",(2 + 3) * 5);


console.log("Answer: ",10 % 3);
