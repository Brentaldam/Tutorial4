x=2;
y=3;
if (x > 2) {
if  (y > 2) {
z = x + y;
console.log("When x = 2 and y = 3","z is: ", z);
}
else {
console.log("When x = 2 and y = 3","x is: ", x);
}
}
z = x + y;
console.log("When x = 2 and y = 3","z is: ", "no output");
console.log("When x = 2 and y = 3","x is: ", "no output");
x=3;
y=2;
if (x > 2) {
    if  (y > 2) {
    z = x + y;
    console.log("When x = 3 and y = 2","z is: ", z);
    }
    else {
    console.log("When x = 3 and y = 2","z is: ", "no output");
    console.log("When x = 3 and y = 2","x is: ", x);
    }
    }

    x=3;
    y=3;
    if (x > 2) {
        if  (y > 2) {
        z = x + y;
        console.log("When x = 3 and y = 3","z is: ", z);
        console.log("When x = 3 and y = 3","x is: ", "no output");
        }
        else {
        console.log("When x = 3 and y = 3","x is: ", x);
        }
        }
//a. When x = 2 and y = 3
//b. When x = 3 and y = 2
//c. When x = 3 and y = 3