let num1 = 0;
{
  num1 = 1; 
  const num2 = 0;
}
console.log("Answer: ",num1); 
console.log("Answer: ",num2); 