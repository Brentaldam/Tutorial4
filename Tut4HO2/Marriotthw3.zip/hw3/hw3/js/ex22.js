//How many times does this loop run and what is the output?
//a. For loop
for (let i = 1; i <= 5; i++) {
   console.log("Answer: ",i);
 }
//b. For loop
for (let i = 1; i <= 5; i++) {
   console.log("Answer: ",i);
   i++;}