console.log("Marriott's Output from Example 6");
const number = Number(prompt("Enter a number:"));
for (let i = 0; i < 11; i++) {
    ans = number * i;
console.log(`${number} x ${i} = ${ans}`)
}