const pi = 3.14;
pi = 3.14159;
console.log("Answer:",pi);