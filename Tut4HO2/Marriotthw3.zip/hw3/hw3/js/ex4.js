console.log("Marriott's Output from Example 2");
const int1 = Number(prompt("Enter 1st integer:"));
const int2 = Number(prompt("Enter 2st integer:"));

ans1 = int1 + int2;
ans2 = int1 - int2;
ans3 = int1 * int2;
ans4 = int1 / int2;
ans5 = int1 % int2;

console.log(`${int1} + ${int2} = ${ans1}`);
console.log(`${int1} - ${int2} = ${ans2}`);
console.log(`${int1} * ${int2} = ${ans3}`);
console.log(`${int1} / ${int2} = ${ans4}`);
console.log(`${int1} % ${int2} = ${ans5}`);