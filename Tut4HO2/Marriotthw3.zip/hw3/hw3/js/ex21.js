//How many times does this loop run and what is the output?
//a. While loop
let number = 1;
while (number <= 5) {
  console.log("Answer: ",number);
  number++;
}
//b. While loop
number = 1;
while (number <= 5) {
  console.log("Answer: ",number);}