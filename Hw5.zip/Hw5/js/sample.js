anArray = [1,2,3,4,5,6,7,8,9,10];
console.log(anArray.filter(value => value % 2 === 0).map(x => x * 2));
console.log(anArray.map(x => x * 2).filter(value => value % 2 === 0));

